#include <iostream>
#include <memory>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <vector>

#include <iostream>
#include <string>
#include <stdexcept> // For std::invalid_argument and std::out_of_range
#include <cstdint>   // For uint16_t
#include <iostream>
#include <sstream>
#include <string>
#include <cstdint>  // For uint16_t
#include <cstdlib>  // For std::strtoul
#include <cctype>   // For std::isspace
#include <algorithm>  // For std::find_if_not
#include "websocketserver.h"

int main()
{
    // 实例化一个自定义的 WebSocket 服务器
    MyWebSocketServer server;

    // 初始化并监听 9002 端口
    server.init(9002);

    std::cout << "[main] WebSocket server starting at port 9002 ..." << std::endl;

    // 启动服务器（阻塞，进入事件循环）
    server.run();
    std::cout << "[main] Server stopped." << std::endl;
    return 0;
}
