#include "websocketserver.h"

#if 0
#include <iostream>
#include <functional>

// 构造函数
MyWebSocketServer::MyWebSocketServer() {
    // 在这里可以设置一些初始值，也可以留空
}

void MyWebSocketServer::init(unsigned short port) {
    // 1. 屏蔽 websocketpp 的自带日志(设置等级为 none)
    ws_server_.clear_access_channels(websocketpp::log::alevel::all);
    ws_server_.clear_error_channels(websocketpp::log::elevel::all);
    
    // 和上面屏蔽websocket日志等价
    // ws_server_.set_access_channels(websocketpp::log::alevel::none);

    // 2. 初始化 Asio
    ws_server_.init_asio();
    // 设置reuse_addr
    ws_server_.set_reuse_addr(true);

    // 3. 设置回调函数，需将 this 指针绑定进来
    ws_server_.set_open_handler(std::bind(&MyWebSocketServer::on_open, this, std::placeholders::_1));
    ws_server_.set_close_handler(std::bind(&MyWebSocketServer::on_close, this, std::placeholders::_1));
    ws_server_.set_message_handler(std::bind(&MyWebSocketServer::on_message, this,
        std::placeholders::_1, std::placeholders::_2));
    ws_server_.set_fail_handler(std::bind(&MyWebSocketServer::on_fail, this, std::placeholders::_1));
    ws_server_.set_http_handler(std::bind(&MyWebSocketServer::on_http, this, std::placeholders::_1));

    // 4. 监听指定IP和端口
    std::string websocket_server_ip_ = "0.0.0.0";
    websocketpp::lib::shared_ptr<websocketpp::lib::asio::ip::tcp::endpoint> endpoint(
                new websocketpp::lib::asio::ip::tcp::endpoint(websocketpp::lib::asio::ip::address::from_string(websocket_server_ip_), port)
        );
    // ws_server_.listen(port);
    ws_server_.listen(*endpoint);

    // 5. 开始接受连接
    ws_server_.start_accept();
}

void MyWebSocketServer::run() {
    // 启动服务器（事件循环）
    ws_server_.run();
}

// 回调：连接建立
void MyWebSocketServer::on_open(connection_hdl hdl) {
    
    /*// 简单演示：给每个连接分配一个用户ID
    std::string user_id = "User_" + std::to_string(connections_.size() + 1);
    connections_[hdl] = user_id;

    std::cout << "[on_open] A new connection established: " << user_id << std::endl;*/
    
    // 先获取连接指针
    auto con = ws_server_.get_con_from_hdl(hdl);
    // 查看客户端请求的路径
    std::string resource = con->get_resource(); // "/chatroom" etc.
    
    std::cout << "[on_open] resource: " << resource << std::endl;
    // 根据路径进行不同处理
    if (resource == "/chatroom") {
        std::cout << "[on_open] This is chatroom WS." << std::endl;
        // ...
    } else {
        std::cout << "[on_open] Unrecognized resource. Possibly reject or default handle." << std::endl;
        // ...
    }

    // 这里可以记录连接到 map 中
    std::string user_id = "User_" + std::to_string(connections_.size() + 1);
    connections_[hdl] = user_id;
    // connections_[hdl] = "some_user_id";
}

// 回调：连接关闭
void MyWebSocketServer::on_close(connection_hdl hdl) {
    auto it = connections_.find(hdl);
    if (it != connections_.end()) {
        std::string user_id = it->second;
        std::cout << "[on_close] Connection closed: " << user_id << std::endl;
        connections_.erase(it);
    } else {
        std::cout << "[on_close] Unknown connection closed" << std::endl;
    }
}

void MyWebSocketServer::on_http(connection_hdl hdl) {
    // HTTP请求处理
    auto con = ws_server_.get_con_from_hdl(hdl);
    std::string resource = con->get_resource();

    std::cout << "[on_http] resource: " << resource << std::endl;

    // 简单返回一个文本
    con->set_body("You are requesting " + resource + " via HTTP!");
    con->set_status(websocketpp::http::status_code::ok);
}

// 回调：收到消息
void MyWebSocketServer::on_message(connection_hdl hdl, server::message_ptr msg) {
    std::string payload = msg->get_payload();
    std::cout << "[on_message] Received: " << payload << std::endl;

    // 示例：原样回发给客户端
    try {
        ws_server_.send(hdl, payload, msg->get_opcode());
    } catch (websocketpp::exception const & e) {
        std::cerr << "[on_message] Error echoing message: " << e.what() << std::endl;
    }
}

// 回调：连接或握手失败
void MyWebSocketServer::on_fail(connection_hdl hdl) {
    // 如果需要获取更多信息可以拿到 connection_ptr
    server::connection_ptr con = ws_server_.get_con_from_hdl(hdl);
    std::cerr << "[on_fail] Connection failed, reason: " 
              << con->get_ec().message() << std::endl;
}
#endif


#include "websocketserver.h"
#include <iostream>
#include <functional>

MyWebSocketServer::MyWebSocketServer() {
    // 构造时先不做任何事
}

MyWebSocketServer::~MyWebSocketServer() {
    // 在服务器退出时，如果还有连接也需要停止它们的线程
    for (auto &pair : connections_) {
        stopConnectionThreads(pair.second);
    }
    connections_.clear();
}

void MyWebSocketServer::init(unsigned short port) {
    // 1. 屏蔽 websocketpp 的自带日志
    ws_server_.clear_access_channels(websocketpp::log::alevel::all);
    ws_server_.clear_error_channels(websocketpp::log::elevel::all);
    // 和上面屏蔽websocket日志等价
    // ws_server_.set_access_channels(websocketpp::log::alevel::none);

    // 2. 初始化 Asio
    ws_server_.init_asio();
    // 设置reuse_addr
    ws_server_.set_reuse_addr(true);

    // 3. 设置回调
    ws_server_.set_open_handler(std::bind(&MyWebSocketServer::on_open, this, std::placeholders::_1));
    ws_server_.set_message_handler(std::bind(&MyWebSocketServer::on_message, this,
                                             std::placeholders::_1, std::placeholders::_2));
    ws_server_.set_close_handler(std::bind(&MyWebSocketServer::on_close, this, std::placeholders::_1));
    ws_server_.set_fail_handler(std::bind(&MyWebSocketServer::on_fail, this, std::placeholders::_1));
    // 如果需要处理普通 HTTP 请求，可设置
    ws_server_.set_http_handler(std::bind(&MyWebSocketServer::on_http, this, std::placeholders::_1));

    // 4. 监听端口
    ws_server_.listen(port);

    // 5. 开始接受连接
    ws_server_.start_accept();
}

void MyWebSocketServer::run() {
    // 进入事件循环
    ws_server_.run();
}

// 连接建立
void MyWebSocketServer::on_open(connection_hdl hdl) {
    // 获取连接指针
    auto con = ws_server_.get_con_from_hdl(hdl);
    // 获取请求路径（resource）
    std::string resource = con->get_resource(); // e.g. "/chatroom"

    // 创建一个连接上下文
    auto ctx = std::make_shared<ConnectionContext>();
    ctx->resource = resource;

    {
        // 放入 map
        connections_[hdl] = ctx;
    }

    // 针对这个连接启动发送线程 & 接收处理线程
    startSendThread(hdl, ctx);
    startRecvThread(hdl, ctx);

    std::cout << "[on_open] New connection. Resource: " << resource << std::endl;
}

// 收到消息
void MyWebSocketServer::on_message(connection_hdl hdl, server::message_ptr msg) {
    auto it = connections_.find(hdl);
    if (it == connections_.end()) {
        // 未知连接
        return;
    }
    auto ctx = it->second;

    // 将消息放入当前连接的 recvQueue
    {
        std::lock_guard<std::mutex> lock(ctx->recvMtx);
        ctx->recvQueue.push(msg->get_payload());
        std::cout << "payload:" << msg->get_payload() << std::endl;
    }
    ctx->recvCv.notify_one();
}

// 连接关闭
void MyWebSocketServer::on_close(connection_hdl hdl) {
    auto it = connections_.find(hdl);
    if (it != connections_.end()) {
        // 停止并回收线程
        stopConnectionThreads(it->second);
        connections_.erase(it);
    }
    std::cout << "[on_close] Connection closed" << std::endl;
}

// 连接失败
void MyWebSocketServer::on_fail(connection_hdl hdl) {
    // 说明连接建立过程中或运行中出现异常
    auto con = ws_server_.get_con_from_hdl(hdl);
    std::cerr << "[on_fail] Connection failed, reason: "
              << con->get_ec().message() << std::endl;

    // 这里也做类似清理
    auto it = connections_.find(hdl);
    if (it != connections_.end()) {
        stopConnectionThreads(it->second);
        connections_.erase(it);
    }
}

// 如果要支持普通 HTTP 请求（非 WebSocket）
void MyWebSocketServer::on_http(connection_hdl hdl) {
    auto con = ws_server_.get_con_from_hdl(hdl);
    
    // 获取 HTTP 方法
    std::string method = con->get_request().get_method();
    if (method == "GET") {
        // 获取请求资源路径，例如 /test
        std::string resource = con->get_resource();
        std::cout << "GET resource: " << resource << std::endl;

        // 这里可以根据 resource 做不同处理...
        // 例如返回一个简单的文本
        con->set_body("Hello from GET request!");
        con->set_status(websocketpp::http::status_code::ok);

    } else if (method == "POST") {
        // ---- 关键代码：获取请求体 ----
        std::string body = con->get_request_body();
        std::cout << "Received POST body: " << body << std::endl;

        // 返回一个简单的文本
        con->set_body("POST request received!");
        con->set_status(websocketpp::http::status_code::ok);

    } else {
        // 其他方法一律返回 405
        con->set_body("Method Not Allowed");
        con->set_status(websocketpp::http::status_code::method_not_allowed);
    }

    #if 0
    // 简单返回一个响应
    con->set_body("<html><body><h1>Hello from HTTP!</h1></body></html>");
    con->set_status(websocketpp::http::status_code::ok);
    #endif
}

// 启动发送线程：循环从 sendQueue 取数据，send给客户端
void MyWebSocketServer::startSendThread(connection_hdl hdl, std::shared_ptr<ConnectionContext> ctx) {
    ctx->sendThread = std::thread([this, hdl, ctx](){
        while (ctx->running) {
            std::unique_lock<std::mutex> lock(ctx->sendMtx);
            // 等待有消息 或者 线程结束
            ctx->sendCv.wait(lock, [ctx] {
                return !ctx->running || !ctx->sendQueue.empty();
            });

            while (!ctx->sendQueue.empty() && ctx->running) {
                std::string msg = ctx->sendQueue.front();
                ctx->sendQueue.pop();
                lock.unlock();

                // 发送到客户端
                try {
                    ws_server_.send(hdl, msg, websocketpp::frame::opcode::text);
                } catch (websocketpp::exception const & e) {
                    std::cerr << "[sendThread] send error: " << e.what() << std::endl;
                }

                lock.lock();
            }
        }
        std::cout << "[sendThread] Exited for resource=" << ctx->resource << std::endl;
    });
}

// 启动接收线程：循环从 recvQueue 取消息，做耗时处理或再发给客户端
void MyWebSocketServer::startRecvThread(connection_hdl hdl, std::shared_ptr<ConnectionContext> ctx) {
    ctx->recvThread = std::thread([this, hdl, ctx](){
        while (ctx->running) {
            std::unique_lock<std::mutex> lock(ctx->recvMtx);
            ctx->recvCv.wait(lock, [ctx] {
                return !ctx->running || !ctx->recvQueue.empty();
            });

            while (!ctx->recvQueue.empty() && ctx->running) {
                std::string msg = ctx->recvQueue.front();
                ctx->recvQueue.pop();
                lock.unlock();

                // 在这里做业务处理，比如：
                std::cout << "[recvThread] Resource=" << ctx->resource
                          << " Received: " << msg << std::endl;

                // 根据 resource 做不同的逻辑
                if (ctx->resource == "/chatroom") {
                    // 演示：回发给客户端
                    {
                        std::lock_guard<std::mutex> sLock(ctx->sendMtx);
                        ctx->sendQueue.push("[echo from chatroom] " + msg);
                    }
                    ctx->sendCv.notify_one();
                } else if (ctx->resource == "/game") {
                    // ... 处理 "/game" 连接的消息
                } else {
                    // 其他路径
                }

                lock.lock();
            }
        }
        std::cout << "[recvThread] Exited for resource=" << ctx->resource << std::endl;
    });
}

// 停止并回收线程
void MyWebSocketServer::stopConnectionThreads(std::shared_ptr<ConnectionContext> ctx) {
    ctx->running = false;
    // 通知两个队列
    ctx->sendCv.notify_all();
    ctx->recvCv.notify_all();

    if (ctx->sendThread.joinable()) {
        ctx->sendThread.join();
    }
    if (ctx->recvThread.joinable()) {
        ctx->recvThread.join();
    }
}