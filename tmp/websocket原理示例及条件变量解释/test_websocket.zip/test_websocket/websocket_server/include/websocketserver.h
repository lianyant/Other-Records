#ifndef __WEBSOCKETSERVER_H__
#define __WEBSOCKETSERVER_H__

#include <websocketpp/config/asio_no_tls.hpp>
#include <websocketpp/server.hpp>
#include <map>
#include <string>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>
#include <memory>
#include <atomic>

#if 0
class MyWebSocketServer {
public:
    // 构造函数
    MyWebSocketServer();

    // 初始化并监听指定端口
    void init(unsigned short port);

    // 运行服务器（进入事件循环）
    void run();

private:
    // 定义一个基于 asio_no_tls 的 server 类型
    typedef websocketpp::server<websocketpp::config::asio> server;

    // 为了简化书写，使用一个别名
    typedef websocketpp::connection_hdl connection_hdl;

    // websocketpp 服务器对象
    server ws_server_;

    // 存储各连接及对应的用户信息
    std::map<connection_hdl, std::string, std::owner_less<connection_hdl>> connections_;

    // 回调函数
    void on_open(connection_hdl hdl);
    void on_close(connection_hdl hdl);
    void on_message(connection_hdl hdl, server::message_ptr msg);
    void on_fail(connection_hdl hdl);
    void on_http(connection_hdl hdl);
};
#endif

// 为了区分，这里定义一个类型别名
typedef websocketpp::server<websocketpp::config::asio> server;
typedef websocketpp::connection_hdl connection_hdl;

// 每个连接的上下文（含发送/接收队列、线程等）
struct ConnectionContext {
    // 与该连接相关的 URL 路径（如 /chatroom, /someapi 等）
    std::string resource;

    // 用于发送消息的队列、线程、同步对象
    std::queue<std::string> sendQueue;
    std::mutex sendMtx;
    std::condition_variable sendCv;
    std::thread sendThread;

    // 用于接收消息后再进行处理的队列、线程、同步对象
    std::queue<std::string> recvQueue;
    std::mutex recvMtx;
    std::condition_variable recvCv;
    std::thread recvThread;

    // 标志位，用于控制线程退出
    std::atomic<bool> running{true};
};

class MyWebSocketServer {
public:
    MyWebSocketServer();
    ~MyWebSocketServer();

    // 初始化并监听指定端口
    void init(unsigned short port);

    // 运行服务器（事件循环）
    void run();

private:
    // 回调函数
    void on_open(connection_hdl hdl);
    void on_message(connection_hdl hdl, server::message_ptr msg);
    void on_close(connection_hdl hdl);
    void on_fail(connection_hdl hdl);
    void on_http(connection_hdl hdl); // 如果需要处理普通HTTP请求

    // 针对某个连接，启动发送消息的线程
    void startSendThread(connection_hdl hdl, std::shared_ptr<ConnectionContext> ctx);

    // 针对某个连接，启动处理接收消息的线程
    void startRecvThread(connection_hdl hdl, std::shared_ptr<ConnectionContext> ctx);

    // 停止并回收某个连接的线程
    void stopConnectionThreads(std::shared_ptr<ConnectionContext> ctx);

private:
    server ws_server_;

    // 存放每个连接的上下文 { connection_hdl -> context }
    // 注意：connection_hdl 不可直接作为 key，需要 owner_less<connection_hdl>
    std::map<connection_hdl, std::shared_ptr<ConnectionContext>, std::owner_less<connection_hdl>> connections_;
};









#endif