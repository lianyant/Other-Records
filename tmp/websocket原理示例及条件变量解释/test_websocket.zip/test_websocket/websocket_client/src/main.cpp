/*#include <iostream>
#include <memory>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <vector>

#include <iostream>
#include <string>
#include <stdexcept> // For std::invalid_argument and std::out_of_range
#include <cstdint>   // For uint16_t
#include <iostream>
#include <sstream>
#include <string>
#include <cstdint>  // For uint16_t
#include <cstdlib>  // For std::strtoul
#include <cctype>   // For std::isspace
#include <algorithm>  // For std::find_if_not
#include "websocketpp/config/asio_no_tls.hpp"
#include "websocketpp/client.hpp"

typedef websocketpp::client<websocketpp::config::asio> client;

void on_open(client* c, websocketpp::connection_hdl hdl) {
    c->send(hdl, "nimamade", websocketpp::frame::opcode::text);
}

void on_message(websocketpp::connection_hdl, client::message_ptr msg) {
    std::cout << "Received message: " << msg->get_payload() << std::endl;
}

int main() {
    client c;

    c.init_asio();

    c.set_open_handler(bind(&on_open, &c, std::placeholders::_1));
    c.set_message_handler(bind(&on_message, std::placeholders::_1, std::placeholders::_2));

    websocketpp::lib::error_code ec;
    client::connection_ptr con = c.get_connection("ws://localhost:9002", ec);

    if (ec) {
        std::cout << "Could not create connection because: " << ec.message() << std::endl;
        return 0;
    }

    c.connect(con);
    c.run();
    return 0;
}
*/


#include "MyWebSocketClient.h"
#include <iostream>
#include <thread>
#include <chrono>

int main() {
    // 1. 创建客户端对象(不依赖openssl)
    MyWebSocketClient client;

    // 2. 连接到服务器 (ws://)
    std::string uri = "ws://127.0.0.1:9002/chatroom";
    client.connect(uri);

    // 3. 启动事件循环 (可放到线程)
    std::thread run_thread([&client](){
        client.run();
    });

    // 稍等片刻，等连接建立
    std::this_thread::sleep_for(std::chrono::seconds(2));

    // 4. 模拟循环发送
    for (int i = 0; ; i++) {
        client.sendMessage("Message " + std::to_string(i));
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }

    // 再等几秒看服务端响应
    std::this_thread::sleep_for(std::chrono::seconds(2));

    // 5. 停止客户端
    client.stop();

    // 6. 等待事件循环退出
    if (run_thread.joinable()) {
        run_thread.join();
    }

    std::cout << "[main] exit." << std::endl;
    return 0;
}
