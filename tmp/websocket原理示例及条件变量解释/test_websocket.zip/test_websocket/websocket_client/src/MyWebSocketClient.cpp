#include "MyWebSocketClient.h"
#include <iostream>
#include <functional>
#include <chrono>

MyWebSocketClient::MyWebSocketClient() {
    // 1. 禁用客户端日志（可根据需要打开）
    client_.clear_access_channels(websocketpp::log::alevel::all);
    client_.clear_error_channels(websocketpp::log::elevel::all);

    // 2. 初始化 asio
    client_.init_asio();

    // 3. 设置回调
    client_.set_open_handler(std::bind(&MyWebSocketClient::on_open, this, std::placeholders::_1));
    client_.set_message_handler(std::bind(&MyWebSocketClient::on_message, this,
                                          std::placeholders::_1, std::placeholders::_2));
    client_.set_close_handler(std::bind(&MyWebSocketClient::on_close, this, std::placeholders::_1));
    client_.set_fail_handler(std::bind(&MyWebSocketClient::on_fail, this, std::placeholders::_1));

    // 启动后台线程（循环发送）
    send_thread_ = std::thread(&MyWebSocketClient::sendingLoop, this);

    // 启动后台线程（处理接收的消息）
    process_thread_ = std::thread(&MyWebSocketClient::messageProcessingLoop, this);
}

MyWebSocketClient::~MyWebSocketClient() {
    // 确保停止并回收线程
    stop();
    if (send_thread_.joinable()) {
        send_thread_.join();
    }
    if (process_thread_.joinable()) {
        process_thread_.join();
    }
}

void MyWebSocketClient::connect(const std::string& uri) {
    // 注意：uri 需是 ws:// 开头(因为不支持 wss://)
    websocketpp::lib::error_code ec;
    client_t::connection_ptr con = client_.get_connection(uri, ec);
    if (ec) {
        std::cerr << "[connect] could not create connection: " << ec.message() << std::endl;
        return;
    }
    conn_hdl_ = con->get_handle();

    // 异步发起连接
    client_.connect(con);
}

void MyWebSocketClient::run() {
    // 事件循环（阻塞执行）
    client_.run();
}

void MyWebSocketClient::sendMessage(const std::string &msg) {
    // 加入队列，唤醒发送线程
    {
        std::lock_guard<std::mutex> lock(send_mtx_);
        send_queue_.push(msg);
    }
    send_cv_.notify_one();
}

void MyWebSocketClient::stop() {
    // 停止标志
    if (running_) {
        running_ = false;
        send_cv_.notify_all();
        recv_cv_.notify_all();

        if (connected_) {
            try {
                client_.close(conn_hdl_, websocketpp::close::status::normal, "Client stop");
            } catch (...) {
                // ignore
            }
        }
    }
}

/* ----------------------- 回调函数 ----------------------- */

// 连接成功
void MyWebSocketClient::on_open(connection_hdl hdl) {
    connected_ = true;
    std::cout << "[on_open] connection established" << std::endl;
    // 可在这里发送初始消息：
    // sendMessage("Hello from on_open!");
}

// 收到消息
void MyWebSocketClient::on_message(connection_hdl hdl, message_ptr msg) {
    std::string payload = msg->get_payload();
    {
        std::lock_guard<std::mutex> lock(recv_mtx_);
        recv_queue_.push(payload);
    }
    recv_cv_.notify_one();
}

// 连接关闭
void MyWebSocketClient::on_close(connection_hdl hdl) {
    connected_ = false;
    std::cout << "[on_close] connection closed" << std::endl;
}

// 连接失败
void MyWebSocketClient::on_fail(connection_hdl hdl) {
    connected_ = false;
    std::cerr << "[on_fail] connection failed" << std::endl;
}

/* ------------------ 后台线程（循环发送 & 消息处理） ------------------ */

// 发送线程
void MyWebSocketClient::sendingLoop() {
    while (running_) {
        // 等待有待发送消息 或 退出
        std::unique_lock<std::mutex> lock(send_mtx_);
        send_cv_.wait(lock, [this]{
            return !running_ || !send_queue_.empty();
        });

        while (!send_queue_.empty() && running_) {
            std::string msg = send_queue_.front();
            send_queue_.pop();

            lock.unlock(); // 解锁以允许其他操作
            if (connected_) {
                try {
                    client_.send(conn_hdl_, msg, websocketpp::frame::opcode::text);
                } catch (websocketpp::exception const & e) {
                    std::cerr << "[sendingLoop] send error: " << e.what() << std::endl;
                }
            }
            lock.lock(); // 重新加锁
        }
    }
    std::cout << "[sendingLoop] exited" << std::endl;
}

// 消息处理线程
void MyWebSocketClient::messageProcessingLoop() {
    while (running_) {
        std::unique_lock<std::mutex> lock(recv_mtx_);
        recv_cv_.wait(lock, [this]{
            return !running_ || !recv_queue_.empty();
        });

        while (!recv_queue_.empty() && running_) {
            std::string msg = recv_queue_.front();
            recv_queue_.pop();

            lock.unlock();
            // 在这里可做耗时业务逻辑
            std::cout << "[messageProcessingLoop] got message: " << msg << std::endl;
            // ...例如解析JSON、处理、再发回...
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            lock.lock();
        }
    }
    std::cout << "[messageProcessingLoop] exited" << std::endl;
}
