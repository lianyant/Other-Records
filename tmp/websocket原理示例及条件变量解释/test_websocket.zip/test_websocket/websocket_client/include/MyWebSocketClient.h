#ifndef MY_WEBSOCKET_CLIENT_H
#define MY_WEBSOCKET_CLIENT_H

#include <websocketpp/config/asio_no_tls.hpp>
#include <websocketpp/client.hpp>

#include <thread>
#include <atomic>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <string>

class MyWebSocketClient {
public:
    MyWebSocketClient();
    ~MyWebSocketClient();

    // 连接到指定的 ws:// 地址 (注意不再支持 wss://)
    void connect(const std::string& uri);

    // 启动事件循环（阻塞）
    void run();

    // 主动发送消息
    void sendMessage(const std::string& msg);

    // 停止客户端
    void stop();

private:
    // 1. websocketpp 客户端类型
    typedef websocketpp::client<websocketpp::config::asio> client_t;

    // 2. 一些常用别名，方便书写
    typedef client_t::connection_ptr connection_ptr;
    typedef websocketpp::config::asio::message_type::ptr message_ptr;
    typedef websocketpp::connection_hdl connection_hdl;

    // ---- 回调函数 ----
    void on_open(connection_hdl hdl);
    void on_message(connection_hdl hdl, message_ptr msg);
    void on_close(connection_hdl hdl);
    void on_fail(connection_hdl hdl);

    // ---- 后台线程 ----
    void sendingLoop();            // 发送消息用的线程
    void messageProcessingLoop();  // 耗时处理消息用的线程

private:
    // websocketpp 客户端对象
    client_t            client_;
    connection_hdl      conn_hdl_;

    // 状态标志
    std::atomic<bool>   connected_{false};
    std::atomic<bool>   running_{true};

    // 后台线程
    std::thread         send_thread_;
    std::thread         process_thread_;

    // 发送消息队列
    std::queue<std::string> send_queue_;
    std::mutex              send_mtx_;
    std::condition_variable send_cv_;

    // 接收消息队列
    std::queue<std::string> recv_queue_;
    std::mutex              recv_mtx_;
    std::condition_variable recv_cv_;
};

#endif
